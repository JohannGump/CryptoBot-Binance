#!/usr/bin/env bash

#Tools installation 
if type brew >/dev/null 2>&1
then
  # Brew est déjà installé
  echo "Homebrew est déjà installé."
  brew upgrade helm kind kubectl yq
else
  # Brew n'est pas installé, procéder à l'installation
  echo "Homebrew n'est pas installé. Installation en cours..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  sudo apt install linuxbrew-wrapper
  brew install helm kind kubectl yq
fi

#sh check-tools.sh

# set the env variable for DAGs Folder
export LOCAL_DAGS_FOLDER=/home/cryptobot/airflow/dags

#Creation of dags folder locaaly
mkdir -p $LOCAL_DAGS_FOLDER
echo "création du dossier de dags '$repo_name'"

if [ -z ${LOCAL_DAGS_FOLDER+x} ];
  then echo "LOCAL_DAGS_FOLDER is unset" && exit 1;
  else echo "LOCAL_DAGS_FOLDER is set to '$LOCAL_DAGS_FOLDER'";
fi

## SET MOUNT PATH TO $LOCAL_DAGS_FOLDER
 yq -i "
 .nodes[1].extraMounts[1].hostPath = \"$LOCAL_DAGS_FOLDER\" |
 .nodes[1].extraMounts[1].containerPath = \"/tmp/dags\"  |
 .nodes[2].extraMounts[1].hostPath = \"$LOCAL_DAGS_FOLDER\" |
 .nodes[2].extraMounts[1].containerPath = \"/tmp/dags\"  |
 .nodes[3].extraMounts[1].hostPath = \"$LOCAL_DAGS_FOLDER\" |
 .nodes[3].extraMounts[1].containerPath = \"/tmp/dags\"
 " kind-cluster.yaml

## CREATE KUBE CLUSTER
# Check if cluster already exist
if kind get clusters | grep -q "airflow-cluster"; then
  echo "Le cluster 'airflow-cluster' existe déjà. Aucune action nécessaire."
else
  echo "Le cluster 'airflow-cluster' n'existe pas. Création en cours..."
  kind create cluster --name airflow-cluster --config kind-cluster.yaml
fi

## CREATE AIRFLOW NAMESPACE
if kubectl get namespace | grep -q "airflow"; then
  echo "Le namespace airflow existe déjà."
else
  echo "Création du namespace airflow."
  kubectl create namespace airflow
fi

## CREATE WEBSERVER SECRET (FERNET KEY)
if kubectl get secret -n airflow | grep -q "my-webserver-secret"; then 
  echo "Le secret my-webserver-secret existe déjà."
else
  echo "Création du secret my-webserver-secret."
  kubectl -n airflow create secret generic my-webserver-secret --from-literal="webserver-secret-key=$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
fi

## CREATE PERSISTENT VOLUME AND CLAIM FOR DAGS
kubectl apply -f dags_volume.yaml


repo_name="apache-airflow"
repo_url="https://airflow.apache.org"
release_name="airflow"
namespace="airflow"

## FETCH LATEST HELM CHART VERSION AND INSTALL AIRFLOW
if helm repo list | grep -q "$repo_name"; then
    echo "Le référentiel '$repo_name' existe déjà."
else
    echo "Ajout du référentiel '$repo_name'."
    helm repo add "$repo_name" "$repo_url"
fi

helm repo update

helm search repo airflow

if helm list -n "$namespace" | grep -q "$release_name"; then
    echo "L'installation Helm '$release_name' existe déjà dans le namespace '$namespace'."
else
    echo "Installation de Helm '$release_name' dans le namespace '$namespace'."
    helm install "$release_name" apache-airflow/airflow --namespace "$namespace" --debug -f values.yaml
fi

#Accessing the UI
kubectl port-forward svc/airflow-webserver 8080:8080 -n airflow